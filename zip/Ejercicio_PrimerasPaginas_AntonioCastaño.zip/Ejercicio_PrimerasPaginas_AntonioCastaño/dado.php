<?php
$numero = rand(1, 6); //Se carga la variable con el numero random del 1 al 6
echo "El número elegido es $numero"; //Se escribe en pantalla el nuemro elegido
