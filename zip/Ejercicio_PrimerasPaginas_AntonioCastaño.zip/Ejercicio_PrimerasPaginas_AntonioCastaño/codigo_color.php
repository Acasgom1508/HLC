<?php
$red = rand(0,255);//Genero la cantidad de rojo
$green = rand(0,255);//Genero la cantidad de verde
$blue = rand(0,255);//Genero la cantidad de azul

print "<p>rgb($red, $green, $blue)</p>";//Muestro el codigo rgb por pantalla
