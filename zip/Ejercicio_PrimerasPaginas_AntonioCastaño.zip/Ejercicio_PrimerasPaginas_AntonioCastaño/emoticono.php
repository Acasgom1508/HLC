<?php
$codigo_emoticono = rand(128512, 128586); //Creo el código del emoticono
print "<p>Emoticono &#$codigo_emoticono con código $codigo_emoticono</p>";//Muestro por pantalla el emoticono con su código correspondiente
