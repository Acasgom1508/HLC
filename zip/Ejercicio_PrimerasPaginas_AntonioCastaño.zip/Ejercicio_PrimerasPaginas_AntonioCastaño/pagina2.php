<?php
echo "<h1>Esto es la página 2</h1>"; //Indicamos en la páguina en la que nos encontramos
echo "¡Hola, mundo!<br>"; //Hacemos el hola mundo y añadimos un salto de linea
echo '<a href="./pagina1.php"> Ir a Página 1 <a/>'; //Terminamos con el enlace a la página 1
