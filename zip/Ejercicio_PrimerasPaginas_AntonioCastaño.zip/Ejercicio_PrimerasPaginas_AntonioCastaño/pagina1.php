<?php
echo "<h1>Esto es la página 1</h1>"; //Indicamos que es la página 1
echo '<a href="./pagina2.php"> Ir a Página 2 <a/>'; //Añadimos el enlace a la página 2
