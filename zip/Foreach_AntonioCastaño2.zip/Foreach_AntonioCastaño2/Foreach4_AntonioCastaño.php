<!DOCTYPE html>
<html>

<head>
    <title>ACTIVIDAD 4</title>
</head>

<body>
    <h1>Buscar estaciones por nombre y mostrar si es un intercambiador o no</h1>
    <form method="POST" action="">
        <label for="buscar">Buscar intercambiadores por estacion:</label>
        <input type="text" id="buscar" name="buscar">
        <button type="submit">Buscar</button>
    </form>

    <?php
    $estacionesMetroMadrid = [
        'Línea 1' => [
            ['estacion' => 'Sol', 'intercambiador' => true],
            ['estacion' => 'Gran Vía', 'intercambiador' => false],
            ['estacion' => 'Tribunal', 'intercambiador' => false],
        ],
        'Línea 2' => [
            ['estacion' => 'Cuatro Caminos', 'intercambiador' => true],
            ['estacion' => 'La Elipa', 'intercambiador' => false],
            ['estacion' => 'Ventas', 'intercambiador' => false],
        ],
        'Línea 3' => [
            ['estacion' => 'Villaverde Alto', 'intercambiador' => false],
            ['estacion' => 'Sierra de Guadalupe', 'intercambiador' => true],
            ['estacion' => 'Emilia Pardo Bazán', 'intercambiador' => false],
        ],
        'Línea 10' => [
            ['estacion' => 'Nuevo Ministerios', 'intercambiador' => true],
            ['estacion' => 'Chamartín', 'intercambiador' => true],
            ['estacion' => 'Berruguete', 'intercambiador' => false],
        ]
    ];

    $input = $_POST['buscar'];
    $encontrada = false;

    foreach ($estacionesMetroMadrid as $estaciones => $infoEstacion) {
        foreach ($infoEstacion as $estacion) {
            if ($input == $estacion['estacion']) {
                echo "{$estacion['estacion']}: Intercambiador: " . ($estacion['intercambiador'] ? 'Sí' : 'No');
                $encontrada = true;
                break;
            }
        }
    }

    if (!$encontrada) {
        echo "No se ha encontrado la estación.";
    }

    ?>

</body>

</html>